import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class PantallaLogin {

	private JFrame frmInicioDeSesin;
	private JTextField txtCorreoElectronico;
	private JPasswordField txtContrasenia;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaLogin window = new PantallaLogin();
					window.frmInicioDeSesin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PantallaLogin() {
		inicializador();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void inicializador() {
		frmInicioDeSesin = new JFrame();
		frmInicioDeSesin.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ernesto Amaral\\Desktop\\aaaaaaaaaaaaaaaaaaa.png"));
		frmInicioDeSesin.setTitle("Sesión");
		frmInicioDeSesin.setResizable(false);
		frmInicioDeSesin.setBounds(100, 100, 249, 354);
		frmInicioDeSesin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInicioDeSesin.getContentPane().setLayout(null);
		
		JLabel iconoSolar = new JLabel("New label");
		iconoSolar.setIcon(new ImageIcon("C:\\Users\\Ernesto Amaral\\Desktop\\ezgif.com-resize.gif"));
		iconoSolar.setBounds(10, 11, 105, 130);
		frmInicioDeSesin.getContentPane().add(iconoSolar);
		
		JLabel lblTitulo = new JLabel("Bienvenido de nuevo, ");
		lblTitulo.setFont(new Font("Poppins SemiBold", Font.BOLD, 16));
		lblTitulo.setBounds(20, 152, 195, 14);
		frmInicioDeSesin.getContentPane().add(lblTitulo);
		
		JLabel lblDesc = new JLabel("inicie sesión para continuar");
		lblDesc.setFont(new Font("Poppins ExtraLight", Font.PLAIN, 12));
		lblDesc.setBounds(20, 165, 169, 14);
		frmInicioDeSesin.getContentPane().add(lblDesc);
		
		JLabel lblCorreo = new JLabel("Correo electrónico: ");
		lblCorreo.setFont(new Font("Poppins", Font.PLAIN, 12));
		lblCorreo.setBounds(20, 190, 125, 14);
		frmInicioDeSesin.getContentPane().add(lblCorreo);
		
		txtCorreoElectronico = new JTextField();
		txtCorreoElectronico.setFont(new Font("Poppins", Font.PLAIN, 12));
		txtCorreoElectronico.setBounds(20, 206, 195, 20);
		frmInicioDeSesin.getContentPane().add(txtCorreoElectronico);
		txtCorreoElectronico.setColumns(10);
		
		JLabel lblContrasenia = new JLabel("Contraseña:");
		lblContrasenia.setFont(new Font("Poppins", Font.PLAIN, 12));
		lblContrasenia.setBounds(20, 237, 82, 14);
		frmInicioDeSesin.getContentPane().add(lblContrasenia);
		
		txtContrasenia = new JPasswordField();
		txtContrasenia.setFont(new Font("Poppins", Font.PLAIN, 11));
		txtContrasenia.setBounds(20, 252, 195, 20);
		frmInicioDeSesin.getContentPane().add(txtContrasenia);
		
		JButton btnIniciarSesion = new JButton("Iniciar Sesión");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String correo = txtCorreoElectronico.getText();
				char[] contrasenia = txtContrasenia.getPassword();
				String contraseniaCompleta = new String(contrasenia);
				
		        if (correo.equals("admin") && contraseniaCompleta.equals("root")) {  //if authentic, navigate user to a new page  
		            
		        	JOptionPane.showMessageDialog(null, "Sesión iniciada correctamente");
		            // Se crea una instancia de la clase MenuPrincipal  
		            MenuABC paginaPrincipal = new MenuABC();  
		              
		            // La hacemos visibible para el usuario  
		            paginaPrincipal.setVisible(true);
		    		frmInicioDeSesin.dispose();
		    		
		        
		        } else {
		            JOptionPane.showMessageDialog(null, "Las credenciales no son correctas, verifique de nuevo.", "Credenciales incorrectas", JOptionPane.ERROR_MESSAGE);
		        }
				
			}
		});
		btnIniciarSesion.setFont(new Font("Poppins", Font.PLAIN, 12));
		btnIniciarSesion.setBounds(20, 283, 195, 20);
		frmInicioDeSesin.getContentPane().add(btnIniciarSesion);
		
		JLabel lblCreditos = new JLabel("Realizado por: ");
		lblCreditos.setFont(new Font("Poppins", Font.BOLD, 11));
		lblCreditos.setBounds(133, 21, 82, 14);
		frmInicioDeSesin.getContentPane().add(lblCreditos);
		
		JLabel lblAmaral = new JLabel("Amaral");
		lblAmaral.setFont(new Font("Poppins", Font.PLAIN, 11));
		lblAmaral.setBounds(172, 37, 51, 14);
		frmInicioDeSesin.getContentPane().add(lblAmaral);
		
		JLabel lblEspinoza = new JLabel("Espinoza");
		lblEspinoza.setFont(new Font("Poppins", Font.PLAIN, 11));
		lblEspinoza.setBounds(161, 51, 51, 14);
		frmInicioDeSesin.getContentPane().add(lblEspinoza);
		
		JLabel lblErnesto = new JLabel("Ernesto");
		lblErnesto.setFont(new Font("Poppins", Font.PLAIN, 11));
		lblErnesto.setBounds(171, 66, 51, 14);
		frmInicioDeSesin.getContentPane().add(lblErnesto);
	}
}
